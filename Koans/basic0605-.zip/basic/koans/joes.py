#!/usr/bin/env python
# -*- coding: utf-8 -*-


class Dog(object):
    def identify(self):
        return "joes dog"
